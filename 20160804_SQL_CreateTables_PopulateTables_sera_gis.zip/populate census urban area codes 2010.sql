--Census Urban Area Codes 2010
--Created May 2016 
​
set search_path to sera_gis_raw, sera_gis, public;
​
begin transaction;
insert into sera_gis."Census Urban Area Codes 2010"
Select a."Census Urban Area Code", a."Census Urban Area Name", a."Census Urban Area Geometry 500k",
  a."Census Urban Area Geometry Centroids"
	FROM 
(Select 
t1."GEOID10" as "Census Urban Area Code", 
t1."NAME10" as "Census Urban Area Name",
ST_Transform(t1.the_geom,5070) as "Census Urban Area Geometry 500k",
ST_Transform(ST_Centroid(t1.the_geom),5070) as "Census Urban Area Geometry Centroids"
FROM sera_gis_raw.cb_2012_us_uac10_500k t1) a
commit;