--Census Counties 2010
--Created May 2016 

set search_path to sera_gis_raw, sera_gis, public;

begin transaction;
insert into sera_gis."Census Counties 2010"
Select a."County FIPS", a."County Name", a."State FIPS", a."State USPS", a."Census County Geometry 20m", a."Census County Geometry 500k",
  a."Census County Geometry Centroids"
	FROM 
(Select 
t1."COUNTY" as "County FIPS", 
t1."NAME" as "County Name",
t1."STATE" as "State FIPS",
t3."STUSAB" as "State USPS",
ST_Transform(t1.the_geom,5070) as "Census County Geometry 20m", 
ST_Transform(t2.the_geom,5070) as "Census County Geometry 500k",
ST_Transform(ST_Centroid(t2.the_geom),5070) as "Census County Geometry Centroids"
FROM sera_gis_raw.gz_2010_us_050_00_20m t1 inner join 
sera_gis_raw.gz_2010_us_050_00_500k t2 ON
t1."COUNTY" = t2."COUNTY" AND
t1."NAME" = t2."NAME" AND
t1."STATE" = t2."STATE"
inner join
sera_gis_raw.states_usps as t3 ON
t1."STATE" = t3."STATE") a
commit;