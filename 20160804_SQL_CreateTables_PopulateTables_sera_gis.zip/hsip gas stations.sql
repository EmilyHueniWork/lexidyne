--HSIP Gas Stations 2015
--Created May 2016 
--See "Populate HSIP Gas Stations.sql" for inserts from raw data 

set search_path to sera_gis, public;

INSERT INTO public.geometry_columns(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")
SELECT '', 'sera_gis', 'HSIP Gas Stations', 'Gas Station Geometry', 2, 5070, 'POINT'
;

select * from public.geometry_columns
where f_table_schema in ('sera_gis_raw', 'sera_gis');

CREATE TABLE sera_gis."HSIP Gas Stations"
(
  "Gas Station ID" integer NOT NULL,
  "Gas Station Name" character varying (100),
  "Gas Station Chain ID" integer,
  "Open 24 hours a day" boolean,
  "Diesel" boolean,
  "Gas Station Geometry" geometry NOT NULL,
  CONSTRAINT enforce_dims_hsip_gas_stations_geometry CHECK (st_ndims("Gas Station Geometry") = 2),
  CONSTRAINT enforce_srid_hsip_gas_stations_geometry CHECK (st_srid("Gas Station Geometry") = 5070)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE sera_gis."HSIP Gas Stations"
    OWNER TO "sera-rw";
GRANT ALL ON TABLE sera_gis."HSIP Gas Stations" TO "sera-rw";
GRANT SELECT ON TABLE sera_gis."HSIP Gas Stations" TO public;
GRANT SELECT ON TABLE sera_gis."HSIP Gas Stations" TO "sera-ro";


CREATE INDEX hsip_gas_stations_gist_geometry
  ON "HSIP Gas Stations"
  USING gist
  ("Gas Station Geometry");
