--Census ZCTA 2010 (Census Zip Code Tabulated Areas 2010)
--Created May 2016 
--See "Populate ZCTA 2010.sql" for inserts from raw data 

set search_path to sera_gis, public;

INSERT INTO public.geometry_columns(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")
SELECT '', 'sera_gis', 'Census ZCTA 2010', 'Census ZCTA Geometry 500k', 2, 5070, 'MULTIPOLYGON'
;
INSERT INTO public.geometry_columns(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")
SELECT '', 'sera_gis', 'Census ZCTA 2010', 'Census ZCTA Geometry Centroids', 2, 5070, 'POINT'
;
select * from public.geometry_columns
where f_table_schema in ('sera_gis_raw', 'sera_gis');

CREATE TABLE sera_gis."Census ZCTA 2010"
(
  "Census ZCTA" character (5) NOT NULL,
  "Census ZCTA Geometry 500k" geometry NOT NULL,
  "Census ZCTA Geometry Centroids" geometry NOT NULL,
  CONSTRAINT pk_census_zcta_2010 PRIMARY KEY ("Census ZCTA"),
  CONSTRAINT enforce_dims_zcta_geometry_500k CHECK (st_ndims("Census ZCTA Geometry 500k") = 2),
  CONSTRAINT enforce_dims_zcta_geometry_centroids CHECK (st_ndims("Census ZCTA Geometry Centroids") = 2),
  CONSTRAINT enforce_srid_zcta_geometry_500k CHECK (st_srid("Census ZCTA Geometry 500k") = 5070),
  CONSTRAINT enforce_srid_zcta_geometry_centroids CHECK (st_srid("Census ZCTA Geometry Centroids") = 5070)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE sera_gis."Census ZCTA 2010"
    OWNER TO "sera-rw";
GRANT ALL ON TABLE sera_gis."Census ZCTA 2010" TO "sera-rw";
GRANT SELECT ON TABLE sera_gis."Census ZCTA 2010" TO public;
GRANT SELECT ON TABLE sera_gis."Census ZCTA 2010" TO "sera-ro";

CREATE INDEX census_zcta_2010_gist_geometry_500k
  ON "Census ZCTA 2010"
  USING gist
  ("Census ZCTA Geometry 500k");

CREATE INDEX census_zcta_2010_gist_geometry_centroid
  ON "Census ZCTA 2010"
  USING gist
  ("Census ZCTA Geometry Centroids");
