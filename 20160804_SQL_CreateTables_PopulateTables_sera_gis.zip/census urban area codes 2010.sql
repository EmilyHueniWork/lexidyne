--Census Urban Area Codes 2010
--Created May 2016 
--See "Populate Census Urban Area Codes 2010.sql" for inserts from raw data 

set search_path to sera_gis, public;

INSERT INTO public.geometry_columns(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")
SELECT '', 'sera_gis', 'Census Urban Area Codes 2010', 'Census Urban Area Geometry 500k', 2, 5070, 'MULTIPOLYGON'
;
INSERT INTO public.geometry_columns(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")
SELECT '', 'sera_gis', 'Census Urban Area Codes 2010', 'Census Urban Area Geometry Centroids', 2, 5070, 'POINT'
;
select * from public.geometry_columns
where f_table_schema in ('sera_gis_raw', 'sera_gis');

CREATE TABLE sera_gis."Census Urban Area Codes 2010"
(
  "Census Urban Area Code" character (5) NOT NULL,
  "Census Urban Area Name" character varying (75) NOT NULL,
  "Census Urban Area Geometry 500k" geometry NOT NULL,
  "Census Urban Area Geometry Centroids" geometry NOT NULL,
  CONSTRAINT pk_census_urban_area_code_2010 PRIMARY KEY ("Census Urban Area Code"),
  CONSTRAINT enforce_dims_urban_area_code_geometry_500k CHECK (st_ndims("Census Urban Area Geometry 500k") = 2),
  CONSTRAINT enforce_dims_urban_area_code_geometry_centroids CHECK (st_ndims("Census Urban Area Geometry Centroids") = 2),
  CONSTRAINT enforce_srid_urban_area_code_geometry_500k CHECK (st_srid("Census Urban Area Geometry 500k") = 5070),
  CONSTRAINT enforce_srid_urban_area_code_geometry_centroids CHECK (st_srid("Census Urban Area Geometry Centroids") = 5070)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE sera_gis."Census Urban Area Codes 2010"
    OWNER TO "sera-rw";
GRANT ALL ON TABLE sera_gis."Census Urban Area Codes 2010" TO "sera-rw";
GRANT SELECT ON TABLE sera_gis."Census Urban Area Codes 2010" TO public;
GRANT SELECT ON TABLE sera_gis."Census Urban Area Codes 2010" TO "sera-ro";

CREATE INDEX census_urbanAreaCodes_2010_gist_geometry_500k
  ON "Census Urban Area Codes 2010"
  USING gist
  ("Census Urban Area Geometry 500k");

CREATE INDEX census_urbanAreaCodes_2010_gist_geometry_centroid
  ON "Census Urban Area Codes 2010"
  USING gist
  ("Census Urban Area Geometry Centroids");
