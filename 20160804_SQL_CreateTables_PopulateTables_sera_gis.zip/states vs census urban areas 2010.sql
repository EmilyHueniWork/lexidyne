--States vs Census Urban Areas 2010
--Created May 2016 
--See "Populate States vs Census Urban Areas 2010.sql" for inserts from raw data 

set search_path to sera_gis, public;

CREATE TABLE sera_gis."States vs Census Urban Areas 2010"
(
  "Census Urban Area Code" character (5),
  "Census Urban Area Name" character varying (75),
  "State FIPS" character(2),
  "Fraction of Urban Area in State" double precision
)
WITH (
  OIDS=FALSE
);
ALTER TABLE sera_gis."States vs Census Urban Areas 2010"
    OWNER TO "sera-rw";
GRANT ALL ON TABLE sera_gis."States vs Census Urban Areas 2010" TO "sera-rw";
GRANT SELECT ON TABLE sera_gis."States vs Census Urban Areas 2010" TO public;
GRANT SELECT ON TABLE sera_gis."States vs Census Urban Areas 2010" TO "sera-ro";