--Populate Polk 2015
--Created May 2016 

set search_path to sera_gis_raw, sera_gis, public;

begin transaction;
insert into sera_gis."Polk 2015"
Select a."State FIPS", a."County FIPS", a."Polk ZIP Code", a."Polk City", a."Census ZCTA", a."ZIP Code" 
	FROM 
(Select 
t1."State FIPS" as "State FIPS", 
t1."County FIPS" as "County FIPS",
t1."Polk ZIP Code" as "Polk ZIP Code",
t1."Polk City" as "Polk City",
t2."zcta5ce10" as "Census ZCTA",
t3."zip" as "ZIP Code"
FROM sera_gis_raw.polk_2015_zips t1 left outer join
sera_gis_raw.cb_2014_us_zcta510_500k t2 ON
t1."Polk ZIP Code" = t2."zcta5ce10"
left outer join
sera_gis_raw.zip_points_20150507 as t3 ON
t1."Polk ZIP Code" = t3."zip") a
commit;


Update sera_gis."Polk 2015"
Set "ZIP Code" = (case
WHEN "Polk ZIP Code" = '00019' then '96130'
WHEN "Polk ZIP Code" = '34095' then '34094'
WHEN "Polk ZIP Code" = '66019' then '66018'
WHEN "Polk ZIP Code" = '00141' then '04455'
WHEN "Polk ZIP Code" = '02565' then '02556'
WHEN "Polk ZIP Code" = '01517' then '01541'
WHEN "Polk ZIP Code" = '00165' then '56686'
WHEN "Polk ZIP Code" = '39072' then '39071'
WHEN "Polk ZIP Code" = '00176' then '03589'
WHEN "Polk ZIP Code" = '44488' then '44486'
WHEN "Polk ZIP Code" = '19542' then '19508'
WHEN "Polk ZIP Code" = '17839' then '17859'
WHEN "Polk ZIP Code" = '18050' then '18013'
WHEN "Polk ZIP Code" = '29430' then '29461'
WHEN "Polk ZIP Code" = '77709' then '77702'
WHEN "Polk ZIP Code" = '98132' then '98101'
else "ZIP Code"
end
);

UPDATE sera_gis."Polk 2015"
SET "Census ZCTA" = b."Census ZCTA"
FROM sera_gis."ZIP Codes 2015" b
WHERE "Polk 2015"."ZIP Code" = b."ZIP Code" and "Polk 2015"."Census ZCTA" is null;