--Populate Polk MHD 2013
--Created May 2016 

set search_path to sera_gis_raw, sera_gis, public;

begin transaction;
insert into sera_gis."Polk MHD 2013"
Select a."State Name", a."Polk MHD ZIP Code", a."Census ZCTA", a."ZIP Code"
	FROM 
(Select 
t1."State Name" as "State Name", 
t1."Polk MHD ZIP Code" as "Polk MHD ZIP Code",
t2."zcta5ce10" as "Census ZCTA",
t3."zip" as "ZIP Code"
FROM sera_gis_raw."polk-mhd-2013-zips" t1 left outer join
sera_gis_raw.cb_2014_us_zcta510_500k t2 ON
t1."Polk MHD ZIP Code" = t2."zcta5ce10"
left outer join
sera_gis_raw.zip_points_20150507 as t3 ON
t1."Polk MHD ZIP Code" = t3."zip") a
commit;


Update sera_gis."Polk MHD 2013"
Set "ZIP Code" = (case
WHEN "Polk MHD ZIP Code" = '20307' THEN '20306'
WHEN "Polk MHD ZIP Code" = '45145' THEN '45176'
WHEN "Polk MHD ZIP Code" = '98205' THEN '98206'
WHEN "Polk MHD ZIP Code" = '19542' THEN '19508'
WHEN "Polk MHD ZIP Code" = '11736' THEN '11735'
WHEN "Polk MHD ZIP Code" = '17942' THEN '17972'
WHEN "Polk MHD ZIP Code" = '22222' THEN '22214'
WHEN "Polk MHD ZIP Code" = '23521' THEN '23514'
WHEN "Polk MHD ZIP Code" = '29573' THEN '29536'
WHEN "Polk MHD ZIP Code" = '30330' THEN '30344'
WHEN "Polk MHD ZIP Code" = '31212' THEN '31207'
WHEN "Polk MHD ZIP Code" = '32215' THEN '32202'
WHEN "Polk MHD ZIP Code" = '45025' THEN '45012'
WHEN "Polk MHD ZIP Code" = '45138' THEN '45169'
WHEN "Polk MHD ZIP Code" = '46223' THEN '46282'
WHEN "Polk MHD ZIP Code" = '55555' THEN '55583'
WHEN "Polk MHD ZIP Code" = '78287' THEN '78212'
WHEN "Polk MHD ZIP Code" = '78781' THEN '78772'
WHEN "Polk MHD ZIP Code" = '78789' THEN '78799'
WHEN "Polk MHD ZIP Code" = '92162' THEN '92102'
WHEN "Polk MHD ZIP Code" = '92164' THEN '92104'
WHEN "Polk MHD ZIP Code" = '92326' THEN '92378'
WHEN "Polk MHD ZIP Code" = '92412' THEN '92408'
WHEN "Polk MHD ZIP Code" = '92414' THEN '92404'
WHEN "Polk MHD ZIP Code" = '94154' THEN '94103'
else "ZIP Code"
end
);

UPDATE sera_gis."Polk MHD 2013"
SET "Census ZCTA" = b."Census ZCTA"
FROM sera_gis."ZIP Codes 2015" b
WHERE "Polk MHD 2013"."ZIP Code" = b."ZIP Code" and "Polk MHD 2013"."Census ZCTA" is null;