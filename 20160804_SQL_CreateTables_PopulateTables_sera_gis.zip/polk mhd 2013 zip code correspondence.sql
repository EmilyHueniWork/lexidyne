-- Table: sera_gis."Polk MHD 2013"

-- DROP TABLE sera_gis."Polk MHD 2013";

CREATE TABLE sera_gis."Polk MHD 2013"
(
	"State Name" character varying (40) NOT NULL,
	"Polk MHD ZIP Code" character (5) NOT NULL,
	"Census ZCTA" character (5),
	"ZIP Code" character (5)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE sera_gis."Polk MHD 2013"
    OWNER TO "sera-rw";
GRANT ALL ON TABLE sera_gis."Polk MHD 2013" TO "sera-rw";
GRANT SELECT ON TABLE sera_gis."Polk MHD 2013" TO public;
GRANT SELECT ON TABLE sera_gis."Polk MHD 2013" TO "sera-ro";