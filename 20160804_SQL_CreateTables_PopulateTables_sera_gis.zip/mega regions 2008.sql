--Mega Regions 2008
--Created May 2016 
--See "Populate Mega Regions 2008.sql" for inserts from raw data 

set search_path to sera_gis, public;

INSERT INTO public.geometry_columns(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")
SELECT '', 'sera_gis', 'Mega Regions 2008', 'Mega Region Geometry 500k', 2, 5070, 'MULTIPOLYGON'
;
INSERT INTO public.geometry_columns(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")
SELECT '', 'sera_gis', 'Mega Regions 2008', 'Mega Region Geometry Centroids', 2, 5070, 'POINT'
;
select * from public.geometry_columns
where f_table_schema in ('sera_gis_raw', 'sera_gis');

CREATE TABLE sera_gis."Mega Regions 2008"
(
  "Mega Region Abbreviation" character varying (3) NOT NULL,
  "Mega Region Name" character varying (25) NOT NULL,
  "Mega Region Geometry 500k" geometry NOT NULL,
  "Mega Region Geometry Centroids" geometry NOT NULL,
  CONSTRAINT pk_mega_region_2008 PRIMARY KEY ("Mega Region Name"),
  CONSTRAINT enforce_dims_mega_region_geometry_500k CHECK (st_ndims("Mega Region Geometry 500k") = 2),
  CONSTRAINT enforce_dims_mega_region_geometry_centroids CHECK (st_ndims("Mega Region Geometry Centroids") = 2),
  CONSTRAINT enforce_srid_mega_region_geometry_500k CHECK (st_srid("Mega Region Geometry 500k") = 5070),
  CONSTRAINT enforce_srid_mega_region_geometry_centroids CHECK (st_srid("Mega Region Geometry Centroids") = 5070)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE sera_gis."Mega Regions 2008"
    OWNER TO "sera-rw";
GRANT ALL ON TABLE sera_gis."Mega Regions 2008" TO "sera-rw";
GRANT SELECT ON TABLE sera_gis."Mega Regions 2008" TO public;
GRANT SELECT ON TABLE sera_gis."Mega Regions 2008" TO "sera-ro";

CREATE INDEX mega_region_2008_gist_geometry_500k
  ON "Mega Regions 2008"
  USING gist
  ("Mega Region Geometry 500k");

CREATE INDEX mega_region_2008_gist_geometry_centroid
  ON "Mega Regions 2008"
  USING gist
  ("Mega Region Geometry Centroids");
