--ZIP Code Areas 2015
--Created May 2016 
--See "Populate ZIP Codes 2015.sql" for inserts from raw data 

set search_path to sera_gis, public;

INSERT INTO public.geometry_columns(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")
SELECT '', 'sera_gis', 'ZIP Codes 2015', 'ZIP Code Geometry', 2, 5070, 'MULTIPOLYGON'
;

INSERT INTO public.geometry_columns(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")
SELECT '', 'sera_gis', 'ZIP Codes 2015', 'ZIP Code Geometry Centroid', 2, 5070, 'POINT'
;

select * from public.geometry_columns
where f_table_schema in ('sera_gis_raw', 'sera_gis');

CREATE TABLE sera_gis."ZIP Codes 2015"
(
  "ZIP Code" character (5) NOT NULL,
  "State and County FIPS" character (5),
  "State FIPS" character (2),
  "Census ZCTA" character (5),
  "ZIP Code Geometry" geometry,
  "ZIP Code Geometry Centroid" geometry,
  CONSTRAINT pk_marketMap_zip_code_2015 PRIMARY KEY ("ZIP Code"),
  CONSTRAINT enforce_dims_zip_code_geometry CHECK (st_ndims("ZIP Code Geometry") = 2),
  CONSTRAINT enforce_dims_zip_code_geometry_centroids CHECK (st_ndims("ZIP Code Geometry Centroid") = 2),
  CONSTRAINT enforce_srid_zip_code_geometry CHECK (st_srid("ZIP Code Geometry") = 5070),
  CONSTRAINT enforce_srid_zip_code_geometry_centroids CHECK (st_srid("ZIP Code Geometry Centroid") = 5070)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE sera_gis."ZIP Codes 2015"
    OWNER TO "sera-rw";
GRANT ALL ON TABLE sera_gis."ZIP Codes 2015" TO "sera-rw";
GRANT SELECT ON TABLE sera_gis."ZIP Codes 2015" TO public;
GRANT SELECT ON TABLE sera_gis."ZIP Codes 2015" TO "sera-ro";


CREATE INDEX zip_codes_2015_gist_geometry
  ON "ZIP Codes 2015"
  USING gist
  ("ZIP Code Geometry");
  
CREATE INDEX zip_codes_2015_gist_geometry_centroid
  ON "ZIP Codes 2015"
  USING gist
  ("ZIP Code Geometry Centroid");
