--Populate ZIP Code Areas 2015
--Created May 2016 

set search_path to sera_gis_raw, sera_gis, public;

begin transaction;
insert into sera_gis."ZIP Codes 2015"
Select a."ZIP Code", a."State and County FIPS", a."State FIPS", a."Census ZCTA", a."ZIP Code Geometry", a."ZIP Code Geometry Centroid"
	FROM 
(Select 
t1."zip" as "ZIP Code", 
t1."fipsstco" as "State and County FIPS",
t1."state_fips" as "State FIPS",
t3."Census ZCTA" as "Census ZCTA",
ST_Transform(t2.the_geom,5070) as "ZIP Code Geometry",
ST_Transform(t1.the_geom,5070) as "ZIP Code Geometry Centroid"
FROM sera_gis_raw.zip_points_20150507 t1 full outer join
sera_gis_raw.zip_polys_20150507 t2 ON
t1.zip = t2.zip
left outer join sera_gis."Census ZCTA 2010" t3
ON t1.zip = t3."Census ZCTA") a
commit;

CREATE TEMPORARY TABLE a AS
(SELECT b."ZIP Code", b."Census ZCTA" AS "ZCTA NULLS", c."Census ZCTA" , (ST_AREA(st_intersection(b."ZIP Code Geometry", c."Census ZCTA Geometry 500k"))/(ST_AREA(b."ZIP Code Geometry"))) as AreaFraction
FROM sera_gis."ZIP Codes 2015" as b, sera_gis."Census ZCTA 2010" as c
WHERE b."ZIP Code Geometry" && c."Census ZCTA Geometry 500k" and b."Census ZCTA" IS NULL
GROUP BY b."ZIP Code", c."Census ZCTA");

Create Temporary Table t4 AS
(SELECT a."ZIP Code", a."Census ZCTA", a.areafraction
FROM a 
WHERE areafraction = (SELECT max(areafraction) FROM a as f where f."ZIP Code" = a."ZIP Code"));


UPDATE sera_gis."ZIP Codes 2015" 
SET "Census ZCTA"= t4."Census ZCTA"
FROM t4
WHERE "ZIP Codes 2015"."ZIP Code" = t4."ZIP Code" and "ZIP Codes 2015"."Census ZCTA" is null;


Create Temporary Table t5 AS(
SELECT a."ZIP Code", b."Census ZCTA", ST_DISTANCE(a."ZIP Code Geometry Centroid", b."Census ZCTA Geometry 500k")
  FROM sera_gis."ZIP Codes 2015" a, sera_gis."Census ZCTA 2010" b
  WHERE a."Census ZCTA" IS NULL and St_DWithin(b."Census ZCTA Geometry 500k", a."ZIP Code Geometry Centroid", 6000)
  ORDER BY ST_DISTANCE);
  CREATE INDEX t5_index_temp
  ON t5 ("ZIP Code", ST_DISTANCE);
  
Create Temporary Table t6 AS(
SELECT t5."ZIP Code", t5."Census ZCTA", t5.ST_DISTANCE
FROM t5
WHERE ST_DISTANCE = (SELECT min(ST_DISTANCE) FROM t5 as f where f."ZIP Code" = t5."ZIP Code"));

UPDATE sera_gis."ZIP Codes 2015" 
SET "Census ZCTA"= t6."Census ZCTA"
FROM t6
WHERE "ZIP Codes 2015"."ZIP Code" = t6."ZIP Code" and "ZIP Codes 2015"."Census ZCTA" is null;

Create Temporary Table t7 as (
Select distinct b."ZIP Code Geometry Centroid" from sera_gis."ZIP Codes 2015" b
WHERE b."Census ZCTA" is null);

UPDATE sera_gis."ZIP Codes 2015"
SET "ZIP Code Geometry Centroid" = NULL 
FROM t7
WHERE "ZIP Codes 2015"."ZIP Code Geometry Centroid" = t7."ZIP Code Geometry Centroid";
