--PADD (Petroleum Administration for Defense Districts)
--Created May 2016 
--See "Populate PADD.sql" for inserts from raw data 

set search_path to sera_gis, public;

INSERT INTO public.geometry_columns(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")
SELECT '', 'sera_gis', 'PADD', 'PADD Geometry', 2, 5070, 'MULTIPOLYGON'
;
INSERT INTO public.geometry_columns(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")
SELECT '', 'sera_gis', 'PADD', 'PADD Geometry Centroids', 2, 5070, 'POINT'
;
select * from public.geometry_columns
where f_table_schema in ('sera_gis_raw', 'sera_gis');

CREATE TABLE sera_gis."PADD"
(
  "PADD ID" character varying (3) NOT NULL,
  "PADD Name" character varying (25) NOT NULL,
  "PADD Geometry" geometry NOT NULL,
  "PADD Geometry Centroids" geometry NOT NULL,
  CONSTRAINT pk_padd PRIMARY KEY ("PADD Name"),
  CONSTRAINT enforce_dims_padd_geometry CHECK (st_ndims("PADD Geometry") = 2),
  CONSTRAINT enforce_dims_padd_geometry_centroids CHECK (st_ndims("PADD Geometry Centroids") = 2),
  CONSTRAINT enforce_srid_padd_geometry CHECK (st_srid("PADD Geometry") = 5070),
  CONSTRAINT enforce_srid_padd_geometry_centroids CHECK (st_srid("PADD Geometry Centroids") = 5070)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE sera_gis."PADD"
    OWNER TO "sera-rw";
GRANT ALL ON TABLE sera_gis."PADD" TO "sera-rw";
GRANT SELECT ON TABLE sera_gis."PADD" TO public;
GRANT SELECT ON TABLE sera_gis."PADD" TO "sera-ro";

CREATE INDEX padd_gist_geometry
  ON "PADD"
  USING gist
  ("PADD Geometry");

CREATE INDEX padd_gist_geometry_centroid
  ON "PADD"
  USING gist
  ("PADD Geometry Centroids");
