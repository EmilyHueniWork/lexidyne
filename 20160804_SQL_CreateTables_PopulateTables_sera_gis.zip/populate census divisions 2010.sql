--Census Divsions 2010
--Created May 2016 

set search_path to sera_gis_raw, sera_gis, public;

create temporary table geoms AS (
    SELECT *, (ST_Dump(the_geom)).geom AS geom 
    FROM gz_2010_us_030_00_500k
    WHERE "NAME" = 'Pacific'
);

create temporary table geoms_all AS (
	(SELECT "NAME", ST_PointOnSurface(geom) AS geom
	FROM geoms 
	ORDER BY "NAME" ASC, ST_Area(geom) DESC
	Limit 1 OFFSET 1)
UNION
	SELECT "NAME", ST_PointOnSurface(the_geom) AS geom
	FROM gz_2010_us_030_00_500k
	WHERE "NAME" <> 'Pacific');
	
create temporary table t3 AS(
	SELECT 
	geoms_all."NAME" AS "NAME",
	gz_2010_us_020_00_20m."NAME" AS "Census Region Name",
	geoms_all.geom as the_geom
	FROM geoms_all left outer join gz_2010_us_020_00_20m ON 
	ST_Within(geoms_all.geom, gz_2010_us_020_00_20m.the_geom)
);

begin transaction;
insert into sera_gis."Census Divisions 2010"
Select a."Census Division Abbreviation", a."Census Division Name", a."Census Region Name", a."Census Division Geometry 20m", a."Census Division Geometry 500k",
  a."Census Division Geometry Centroids"
	FROM 
(Select 
t1."DIVISION" as "Census Division Abbreviation", 
t1."NAME" as "Census Division Name",
t3."Census Region Name" as "Census Region Name",
ST_Transform(t1.the_geom,5070) as "Census Division Geometry 20m", 
ST_Transform(t2.the_geom,5070) as "Census Division Geometry 500k",
ST_Transform(t3.the_geom,5070) as "Census Division Geometry Centroids"
FROM sera_gis_raw.gz_2010_us_030_00_20m t1 inner join 
sera_gis_raw.gz_2010_us_030_00_500k t2 ON
t1."DIVISION" = t2."DIVISION" AND
t1."NAME" = t2."NAME"
inner join t3 ON
t1."NAME" = t3."NAME") a
commit;

Update sera_gis."Census Divisions 2010"
SET "Census Division Abbreviation" = CASE
	WHEN "Census Division Name" = 'Pacific' THEN 'PA'
	WHEN "Census Division Name" = 'Mountain' THEN 'MTN'
	WHEN "Census Division Name" = 'West South Central' THEN 'WSC'
	WHEN "Census Division Name" = 'East South Central' THEN 'ESC'
	WHEN "Census Division Name" = 'South Atlantic' THEN 'SA'
	WHEN "Census Division Name" = 'West North Central' THEN 'WNC'
	WHEN "Census Division Name" = 'East North Central' THEN 'ENC'
	WHEN "Census Division Name" = 'Middle Atlantic' THEN 'MA'
	WHEN "Census Division Name" = 'New England' THEN 'NE'
	END;