--Populate HSIP Enrg Gas Stations
--Created May 2016 

set search_path to sera_gis_raw, sera_gis, public;

begin transaction;
insert into sera_gis."HSIP Enrg Gas Stations"
Select a."Enrg Station ID", a."Gas Station ID", a."Gas Station Name", a."Gas Station Chain ID", a."Open 24 hours a day", a."Diesel", a."Gas Station Geometry"
	FROM 
(Select 
t1."objectid" as "Enrg Station ID",
t1."poi_id" as "Gas Station ID", 
t1."poi_name" as "Gas Station Name",
t1."chain_id" as "Gas Station Chain ID",
(case when t1."open_24" = 'Y' then true
  when t1."open_24" = 'N' then false end) as "Open 24 hours a day",
(case when t1."diesel" = 'Y' then true 
   when t1."diesel" = 'N' then false end) as "Diesel",
ST_Transform(t1.the_geom,5070) as "Gas Station Geometry"
FROM sera_gis_raw.enrg_gas_stations t1
) a
commit;