--Mega Regions 2008
--Created May 2016 

set search_path to sera_gis_raw, sera_gis, public;

begin transaction;
insert into sera_gis."Mega Regions 2008"
Select a."Mega Region Abbreviation", a."Mega Region Name", a."Mega Region Geometry 500k",
  a."Mega Region Geometry Centroids"
	FROM 
(Select 
t1."gid" as "Mega Region Abbreviation", 
t1."name" as "Mega Region Name", 
ST_Transform(t1.the_geom,5070) as "Mega Region Geometry 500k",
ST_Transform(ST_PointOnSurface(t1.the_geom),5070) as "Mega Region Geometry Centroids"
FROM sera_gis_raw.mega_region_smooth t1
WHERE "name" is not null and "name" <> 'Great Lakes') a
commit;

Create Temporary Table t2 As(
Select ST_UNION(the_geom) as the_geom
FROM sera_gis_raw.mega_region_smooth
WHERE "name" is null or "name" = 'Great Lakes');

begin transaction;
insert into sera_gis."Mega Regions 2008"
Select a."Mega Region Abbreviation", a."Mega Region Name", a."Mega Region Geometry 500k",
  a."Mega Region Geometry Centroids"
	FROM 
(Select 
t1."gid" as "Mega Region Abbreviation", 
t1."name" as "Mega Region Name", 
ST_Transform(t2.the_geom,5070) as "Mega Region Geometry 500k",
ST_Transform(ST_PointOnSurface(t2.the_geom),5070) as "Mega Region Geometry Centroids"
FROM t2, sera_gis_raw.mega_region_smooth t1
WHERE t1."name" = 'Great Lakes') a
commit;

Update sera_gis."Mega Regions 2008"
SET "Mega Region Abbreviation" = CASE
WHEN "Mega Region Name" = 'Great Lakes' THEN 'GL'
WHEN "Mega Region Name" = 'Florida' THEN 'FL'
WHEN "Mega Region Name" = 'Cascadia' THEN 'CS'
WHEN "Mega Region Name" = 'Gulf Coast' THEN 'GC'
WHEN "Mega Region Name" = 'Texas Triangle' THEN 'TT'
WHEN "Mega Region Name" = 'Cascadia Canada' THEN 'CSC'
WHEN "Mega Region Name" = 'Arizona Sun Corridor' THEN 'ASC'
WHEN "Mega Region Name" = 'Piedmont Atlantic' THEN 'PA'
WHEN "Mega Region Name" = 'Southern California' THEN 'SCA'
WHEN "Mega Region Name" = 'Front Range' THEN 'FR'
WHEN "Mega Region Name" = 'Northern California' THEN 'NCA'
WHEN "Mega Region Name" = 'Northeast' THEN 'NE'
END;