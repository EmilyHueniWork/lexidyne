﻿--Census Regions 2010
--Created May 2016 

set search_path to sera_gis_raw, sera_gis, public;

create temporary table geoms AS (
    SELECT *, (ST_Dump(the_geom)).geom AS geom 
    FROM gz_2010_us_020_00_500k
    WHERE "NAME" = 'West'
);

create temporary table t3 AS (
	(SELECT "NAME", ST_Centroid(geom) AS geom
	FROM geoms 
	ORDER BY "NAME" ASC, ST_Area(geom) DESC
	Limit 1)
UNION
	SELECT "NAME", ST_Centroid(the_geom) AS geom
	FROM gz_2010_us_020_00_500k
	WHERE "NAME" <> 'West');

begin transaction;
insert into sera_gis."Census Regions 2010"
Select a."Census Region Abbreviation", a."Census Region Name", a."Census Region Geometry 20m", a."Census Region Geometry 500k",
  a."Census Region Geometry Centroids"
	FROM 
(Select 
t1."REGION" as "Census Region Abbreviation", 
t1."NAME" as "Census Region Name",
ST_Transform(t1.the_geom,5070) as "Census Region Geometry 20m", 
ST_Transform(t2.the_geom,5070) as "Census Region Geometry 500k",
ST_Transform(t3.geom,5070) as "Census Region Geometry Centroids"
FROM sera_gis_raw.gz_2010_us_020_00_20m t1 inner join 
sera_gis_raw.gz_2010_us_020_00_500k t2 ON
t1."REGION" = t2."REGION" AND
t1."NAME" = t2."NAME"
inner join 
t3 ON 
t1."NAME" = t3."NAME") a
commit;

Update sera_gis."Census Regions 2010"
SET "Census Region Abbreviation" = CASE
	WHEN "Census Region Name" = 'Northeast' THEN 'N'
	WHEN "Census Region Name" = 'Midwest' THEN 'M'
	WHEN "Census Region Name" = 'South' THEN 'S'
	WHEN "Census Region Name" = 'West' THEN 'W'
	END;