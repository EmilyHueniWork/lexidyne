--Populate PADD (Petroleum Administration for Defense Districts)
--Created May 2016 

set search_path to sera_gis_raw, sera_gis, public;

Create Temporary Table t1 AS(
  SELECT "PADD", "Name", ST_Buffer(the_geom, 0) as the_geom
  FROM sera_gis_raw."US_PADD"
);

begin transaction;
	insert into sera_gis."PADD"
	Select a."PADD ID", a."PADD Name", a."PADD Geometry",
	  a."PADD Geometry Centroids"
		FROM 
	(Select 
	t1."PADD" as "PADD ID", 
	t1."Name" as "PADD Name", 
	ST_Transform(t1.the_geom,5070) as "PADD Geometry",
	ST_Transform(ST_PointOnSurface(t1.the_geom),5070) as "PADD Geometry Centroids"
	FROM t1
	WHERE "Name" <> 'West Coast') a
commit;

Create Temporary Table t2 As(
	Select *
	FROM
		(SELECT
		ST_UNION(t1.the_geom) as the_geom
		FROM t1
		WHERE "Name" = 'West Coast') a,
		(Select 
		"PADD",
		"Name",
		ST_Centroid(the_geom) as the_geom_cent
		FROM t1
		WHERE "Name" = 'West Coast'
		ORDER BY ST_Area(the_geom) DESC
		LIMIT 1 OFFSET 1) b
		);

begin transaction;
	insert into sera_gis."PADD"
	Select c."PADD ID", c."PADD Name", c."PADD Geometry",
	  c."PADD Geometry Centroids"
		FROM 
	(Select 
	t2."PADD" as "PADD ID", 
	t2."Name" as "PADD Name", 
	ST_Transform(t2.the_geom,5070) as "PADD Geometry",
	ST_Transform(t2.the_geom_cent,5070) as "PADD Geometry Centroids"
	FROM t2) c
commit;