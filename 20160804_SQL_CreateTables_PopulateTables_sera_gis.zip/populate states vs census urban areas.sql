--Populate States vs Census Urban Areas
--Created May 2016 

set search_path to sera_gis_raw, sera_gis, public;

Create Temporary Table t1 as (
	SELECT t2.*, t3."State FIPS", ST_Area(ST_Intersection(t2."Census Urban Area Geometry 500k", t3."Census State Geometry 500k"))/ST_Area(t2."Census Urban Area Geometry 500k") fraction
	FROM sera_gis."Census Urban Area Codes 2010" t2 left outer join sera_gis."Census States 2010" t3 on
	t2."Census Urban Area Geometry 500k" && t3."Census State Geometry 20m"
	ORDER BY t2."Census Urban Area Name"
);

begin transaction;
insert into sera_gis."States vs Census Urban Areas 2010"
Select a."Census Urban Area Code", a."Census Urban Area Name", a."State FIPS", a."Fraction of Urban Area in State"
	FROM 
(Select  
t1."Census Urban Area Code" as "Census Urban Area Code",
t1."Census Urban Area Name" AS "Census Urban Area Name",
t1."State FIPS" AS "State FIPS",
t1."fraction" AS "Fraction of Urban Area in State"
FROM t1
WHERE  fraction<>0 or fraction is null) a
commit;




Create Temporary Table b as (Select d.*, St_Area(d."Census Urban Area Geometry 500k") UrbanArea
FROM sera_gis."Census Urban Area Codes 2010" d inner join (
	SELECT "Census Urban Area Name", ABS(SUM("fraction")-1), count("fraction")
	FROM t1
	GROUP BY "Census Urban Area Name"
	ORDER BY ABS desc
	) c 
ON d."Census Urban Area Name" = c."Census Urban Area Name"
Where c.abs>0
);

Create Temporary Table d as (
SELECT b.*, ST_Difference(b."Census Urban Area Geometry 500k", c."Census State Geometry 500k")
FROM b, sera_gis."Census States 2010" c
);
