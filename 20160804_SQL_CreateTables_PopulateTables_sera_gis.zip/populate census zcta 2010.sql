--Census Zip Code Tabulated Areas 2010
--Created May 2016 
​
set search_path to sera_gis_raw, sera_gis, public;
​
begin transaction;
insert into sera_gis."Census ZCTA 2010"
Select a."Census ZCTA", a."Census ZCTA Geometry 500k",
  a."Census ZCTA Geometry Centroids"
	FROM 
(Select 
t1."zcta5ce10" as "Census ZCTA", 
ST_Transform(ST_Force_2D(ST_Buffer(t1.the_geom, 0)),5070) as "Census ZCTA Geometry 500k",
ST_Transform(ST_Centroid(t1.the_geom),5070) as "Census ZCTA Geometry Centroids"
FROM sera_gis_raw.cb_2014_us_zcta510_500k t1) a
commit;