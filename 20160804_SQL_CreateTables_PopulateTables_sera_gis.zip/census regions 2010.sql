--Census Regions 2010
--Created May 2016 
--See "Populate Census Regions 2010.sql" for inserts from raw data 

set search_path to sera_gis, public;

INSERT INTO public.geometry_columns(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")
SELECT '', 'sera_gis', 'Census Regions 2010', 'Census Region Geometry 20m', 2, 5070, 'MULTIPOLYGON'
;
INSERT INTO public.geometry_columns(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")
SELECT '', 'sera_gis', 'Census Regions 2010', 'Census Region Geometry 500k', 2, 5070, 'MULTIPOLYGON'
;
INSERT INTO public.geometry_columns(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")
SELECT '', 'sera_gis', 'Census Regions 2010', 'Census Region Geometry Centroids', 2, 5070, 'POINT'
;
select * from public.geometry_columns
where f_table_schema in ('sera_gis_raw', 'sera_gis');

CREATE TABLE sera_gis."Census Regions 2010"
(
  "Census Region Abbreviation" character (1) NOT NULL,
  "Census Region Name" character varying (25) NOT NULL,
  "Census Region Geometry 20m" geometry NOT NULL,
  "Census Region Geometry 500k" geometry NOT NULL,
  "Census Region Geometry Centroids" geometry NOT NULL,
  CONSTRAINT pk_census_region_2010 PRIMARY KEY ("Census Region Abbreviation"),
  CONSTRAINT enforce_dims_region_geometry_20m CHECK (st_ndims("Census Region Geometry 20m") = 2),
  CONSTRAINT enforce_dims_region_geometry_500k CHECK (st_ndims("Census Region Geometry 500k") = 2),
  CONSTRAINT enforce_dims_region_geometry_centroids CHECK (st_ndims("Census Region Geometry Centroids") = 2),
  CONSTRAINT enforce_srid_region_geometry_20m CHECK (st_srid("Census Region Geometry 20m") = 5070),
  CONSTRAINT enforce_srid_region_geometry_500k CHECK (st_srid("Census Region Geometry 500k") = 5070),
  CONSTRAINT enforce_srid_region_geometry_centroids CHECK (st_srid("Census Region Geometry Centroids") = 5070)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE sera_gis."Census Regions 2010"
    OWNER TO "sera-rw";
GRANT ALL ON TABLE sera_gis."Census Regions 2010" TO "sera-rw";
GRANT SELECT ON TABLE sera_gis."Census Regions 2010" TO public;
GRANT SELECT ON TABLE sera_gis."Census Regions 2010" TO "sera-ro";

CREATE INDEX census_regions_2010_gist_geometry_20m
  ON "Census Regions 2010"
  USING gist
  ("Census Region Geometry 20m");

CREATE INDEX census_regions_2010_gist_geometry_500k
  ON "Census Regions 2010"
  USING gist
  ("Census Region Geometry 500k");

CREATE INDEX census_regions_2010_gist_geometry_centroid
  ON "Census Regions 2010"
  USING gist
  ("Census Region Geometry Centroids");
