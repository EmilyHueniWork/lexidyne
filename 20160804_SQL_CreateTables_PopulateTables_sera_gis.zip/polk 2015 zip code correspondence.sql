-- Table: sera_gis_raw.polk-2015-zips

-- DROP TABLE sera_gis_raw.polk-2015-zips;

CREATE TABLE sera_gis."Polk 2015"
(
	"State FIPS" character(2) NOT NULL,
	"County FIPS" character (3) NOT NULL,
	"Polk ZIP Code" character (5) NOT NULL,
	"Polk City" character varying (40) NOT NULL,
	"Census ZCTA" character (5),
	"ZIP Code" character (5),
	CONSTRAINT pk_polk_2015 PRIMARY KEY ("County FIPS", "Polk ZIP Code", "Polk City")
)
WITH (
  OIDS=FALSE
);
ALTER TABLE sera_gis."Polk 2015"
    OWNER TO "sera-rw";
GRANT ALL ON TABLE sera_gis."Polk 2015" TO "sera-rw";
GRANT SELECT ON TABLE sera_gis."Polk 2015" TO public;
GRANT SELECT ON TABLE sera_gis."Polk 2015" TO "sera-ro";