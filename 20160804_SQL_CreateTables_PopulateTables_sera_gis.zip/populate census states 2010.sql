--Census States 2010
--Created May 2016 

set search_path to sera_gis_raw, sera_gis, public;

begin transaction;
insert into sera_gis."Census States 2010"
Select a."State FIPS", a."State Name", a."State USPS",a."Census State Geometry 20m", a."Census State Geometry 500k",
  a."Census State Geometry Centroids"
	FROM 
(Select 
t1."STATE" as "State FIPS", 
t1."NAME" as "State Name",
t3."STUSAB" as "State USPS",
ST_Transform(t1.the_geom,5070) as "Census State Geometry 20m", 
ST_Transform(t2.the_geom,5070) as "Census State Geometry 500k",
ST_Transform(ST_Centroid(t2.the_geom),5070) as "Census State Geometry Centroids"
FROM sera_gis_raw.gz_2010_us_040_00_20m t1 inner join 
sera_gis_raw.gz_2010_us_040_00_500k t2 ON
t1."STATE" = t2."STATE" AND
t1."NAME" = t2."NAME"
inner join
sera_gis_raw.states_usps as t3 ON
t1."STATE" = t3."STATE") a
commit;