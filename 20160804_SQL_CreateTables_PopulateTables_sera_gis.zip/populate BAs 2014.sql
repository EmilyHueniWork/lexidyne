--BAs 2014
--Created May 2016 

set search_path to sera_gis_raw, sera_gis, public;

begin transaction;
insert into sera_gis."BAs 2014"
Select a."BA Name", a."BAs Geometry", a."BAs Geometry Centroids"
	FROM 
(Select  
t1."ba" as "BA Name",
ST_Transform(t1.the_geom,5070) as "BAs Geometry", 
ST_Transform(ST_PointOnSurface(t1.the_geom),5070) as "BAs Geometry Centroids"
FROM sera_gis_raw."BAs_updated_20141021" t1) a
commit;
